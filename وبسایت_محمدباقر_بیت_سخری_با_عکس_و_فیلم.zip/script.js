(() => {
  'use strict';
  const data = window.STUDENT_CONTENT || {};
  const get = id => document.getElementById(id);
  get('student-name').textContent = data.name || 'پرونده فرهنگی دانش‌آموز';
  get('intro').textContent = data.introduction || '';
  document.title = `${data.name || 'پرونده فرهنگی'} | پرونده فرهنگی`;
  const list = get('activity-list');
  (data.activities || []).forEach(activity => {
    const card = document.createElement('article'); card.className = 'activity';
    const icon = document.createElement('div'); icon.className = 'activity-symbol'; icon.textContent = '✦';
    const section = document.createElement('div');
    const title = document.createElement('h3'); title.textContent = activity.title;
    const desc = document.createElement('p'); desc.textContent = activity.description;
    const badge = document.createElement('span'); badge.className = 'pill'; badge.textContent = [activity.type,activity.date].filter(Boolean).join(' · ');
    section.append(title,desc,badge); card.append(icon,section); list.append(card);
  });
  const media = get('media-content');
  const lightbox = get('lightbox');
  const closeLightbox = () => {lightbox.hidden = true; document.body.style.overflow='';};
  get('lightbox').querySelector('button').addEventListener('click',closeLightbox);
  lightbox.addEventListener('click',e=>{if(e.target===lightbox)closeLightbox();});
  document.addEventListener('keydown', e=>{if(e.key==='Escape')closeLightbox();});
  function showMedia(kind) {
    media.replaceChildren();
    const items = data[kind] || [];
    if(!items.length){
      const empty = document.createElement('div');empty.className='empty';
      const icon=document.createElement('div');icon.className='empty-icon';icon.textContent=kind==='photos'?'▧':'▷';
      const title=document.createElement('strong'); title.textContent=kind==='photos'?'گالری تصاویر در حال تکمیل است':'فیلم‌های مراسم به‌زودی افزوده می‌شوند';
      const desc=document.createElement('p');desc.textContent='پس از آماده‌سازی و تأیید تصاویر و فیلم‌ها، این قسمت به‌روزرسانی خواهد شد.';
      empty.append(icon,title,desc); media.append(empty);return;
    }
    items.forEach(item=>{
      const card=document.createElement('article');card.className='media-item';
      if(kind==='photos'){
        const btn=document.createElement('button');btn.type='button';btn.setAttribute('aria-label',`بزرگ‌نمایی ${item.title || 'تصویر'}`);
        const img=document.createElement('img');img.src=item.src;img.alt=item.alt || item.title || 'تصویر فعالیت';img.loading='lazy';
        btn.addEventListener('click',()=>{const big=lightbox.querySelector('img');big.src=item.src;big.alt=img.alt;lightbox.querySelector('p').textContent=item.title || '';lightbox.hidden=false;document.body.style.overflow='hidden';});btn.append(img);card.append(btn);
      } else {const video=document.createElement('video');video.src=item.src;video.controls=true;video.preload='metadata';video.playsInline=true;if(item.poster)video.poster=item.poster;card.append(video);}
      const title=document.createElement('strong');title.textContent=item.title || '';card.append(title);media.append(card);
    });
  }
  document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>{
    document.querySelectorAll('.tab').forEach(tab=>{tab.classList.remove('active');tab.setAttribute('aria-selected','false');});
    btn.classList.add('active');btn.setAttribute('aria-selected','true');showMedia(btn.dataset.tab);
  }));
  showMedia('photos');
})();
